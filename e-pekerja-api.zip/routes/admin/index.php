<?php

include_once __DIR__ . '/dashboard.php';
include_once __DIR__ . '/master_data.php';
include_once __DIR__ . '/pegawai.php';
include_once __DIR__ . '/pembaruan_sk.php';
include_once __DIR__ . '/duk.php';
include_once __DIR__ . '/masa_kerja.php';
include_once __DIR__ . '/penghargaan.php';
include_once __DIR__ . '/pensiun.php';
include_once __DIR__ . '/mutasi.php';
include_once __DIR__ . '/kenaikan_pangkat.php';
include_once __DIR__ . '/users.php';
include_once __DIR__ . '/riwayat_golongan.php';
include_once __DIR__ . '/struktur.php';
include_once __DIR__ . '/berkas_kp.php';
include_once __DIR__ . '/pegawai_berhenti.php';
