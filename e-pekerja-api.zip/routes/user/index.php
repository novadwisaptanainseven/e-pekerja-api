<?php

include_once __DIR__ . '/dashboard.php';
include_once __DIR__ . '/data_kepegawaian.php';
include_once __DIR__ . '/akun.php';
include_once __DIR__ . '/master_data.php';
include_once __DIR__ . '/pegawai.php';
include_once __DIR__ . '/berkas_kp.php';
