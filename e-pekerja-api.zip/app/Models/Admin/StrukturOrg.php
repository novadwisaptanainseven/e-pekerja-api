<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StrukturOrg extends Model
{
    use HasFactory;

    protected $table = "struktur_org";
    protected $guarded = [];
}
