<div class="ttd-container" style="text-align: center; width: 300px; margin-left: auto; font-family: arial">
        <p style="margin-bottom: 50px;">Kepala Dinas</p>

        <p style="text-align: center">
            <span style="text-decoration: underline">{{$ttd->nama}}</span> <br>
            {{$ttd->ket_golongan}} ({{$ttd->golongan}}) <br>
            NIP. {{$ttd->nip}}
        </p>
    </div>