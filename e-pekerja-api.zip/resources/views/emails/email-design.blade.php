@component('mail::message')
# Halo Pegawai

@component('mail::panel', ['url' => ''])
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat repellendus sequi amet dolorum delectus architecto sunt sed id. Dolore, velit! Corporis unde eligendi ipsam maiores dignissimos, suscipit magni nesciunt omnis.
@endcomponent

Terima Kasih,<br>
{{ config('app.name') }}
@endcomponent
