<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <p><b>Tanggal</b> : <?php echo e($date); ?></p>

    <h2 style="font-family: Arial, Helvetica, sans-serif"><?php echo e($title); ?></h2>

    <!-- Content -->

    <?php switch($jenis):
    case ('pns'): ?>
    <table class="my-table" cellpadding="5" border="1">
        <tr class="bg-orange">
            <th>Nama/NIP</th>
            <th>Golongan</th>
            <th>Jabatan</th>
            <th>Eselon</th>
            <th>Bidang</th>
            <th>Jenis Kelamin</th>
            <th>No. HP</th>
            <th>No. KTP</th>
            <th>Email</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td valign="top">
                <?php echo e($d->nama); ?><br>
                (<?php echo e($d->nip); ?>)
            </td>
            <td valign="top"><?php echo e($d->ket_golongan . "(" . $d->golongan . ")"); ?></td>
            <td valign="top"><?php echo e($d->jabatan); ?></td>
            <td valign="top"><?php echo e($d->ket_eselon . "(" . $d->eselon . ")"); ?></td>
            <td valign="top"><?php echo e($d->bidang); ?></td>
            <td valign="top"><?php echo e($d->jenis_kelamin); ?></td>
            <td valign="top"><?php echo e($d->no_hp); ?></td>
            <td valign="top"><?php echo e($d->no_ktp); ?></td>
            <td valign="top"><?php echo e($d->email); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php break; ?>

    <?php case ('ptth'): ?>
    <table class="my-table" cellpadding="5" border="1">
        <tr class="bg-orange">
            <th>Nama/NIK</th>
            <th>Penetap SK, No. SK, Tanggal, TMT</th>
            <!-- <th>Tgl. Penetapan SK</th>
            <th>No. SK</th>
            <th>Tgl. Mulai Tugas</th> -->
            <th>Tugas Pokok (Jabatan)</th>
            <th>Gaji Pokok</th>
            <th>Jenis Kelamin</th>
            <th>No. HP</th>
            <th>Bidang</th>
            <th>Email</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td valign="top">
                <?php echo e($d->nama); ?><br>
                (<?php echo e($d->nik); ?>)
            </td>
            <td valign="top">
                - <b>Penetap:</b> <?php echo e($d->penetap_sk); ?> <br>
                - <b>NO.</b> <?php echo e($d->no_sk); ?> <br>
                - <b>TGL.</b> <?php echo e(date("d/m/Y", strtotime($d->tgl_penetapan_sk))); ?> <br>
                - <b>TMT.</b> <?php echo e($d->tgl_mulai_tugas); ?>

            </td>
            <!-- <td><?php echo e(date("d/m/Y", strtotime($d->tgl_penetapan_sk))); ?></td>
            <td><?php echo e($d->no_sk); ?></td>
            <td><?php echo e(date("d/m/Y", strtotime($d->tgl_mulai_tugas))); ?></td> -->
            <td valign="top"><?php echo e($d->jabatan); ?></td>
            <td valign="top">Rp. <?php echo e(number_format($d->gaji_pokok,2,',','.')); ?></td>
            <td valign="top"><?php echo e($d->jenis_kelamin); ?></td>
            <td valign="top"><?php echo e($d->no_hp); ?></td>
            <td valign="top"><?php echo e($d->bidang); ?></td>
            <td valign="top"><?php echo e($d->email); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php break; ?>

    <?php case ('pttb'): ?>
    <table class="my-table" cellpadding="5" border="1">
        <tr class="bg-orange">
            <th style="width: 150px;">Nama/NIPB</th>
            <th style="width: 80px;">Penetap SK, No. SK, Tanggal, TMT</th>
            <!-- <th>Tgl. Penetapan SK</th>
            <th>No. SK</th>
            <th>Tgl. Mulai Tugas</th> -->
            
            <th style="width: 80px;">Masa Kerja</th>
            <th>Gaji Pokok</th>
            <th>Tugas Pokok (Jabatan)</th>
            <th>Jenis Kelamin</th>
            <th>No. HP</th>
            <th>No. KTP</th>
            <th>Email</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td valign="top">
                <?php echo e($d->nama); ?><br>
                (<?php echo e($d->nip); ?>)
            </td>
            <td valign="top">
                - <b>Penetap:</b> <?php echo e($d->penetap_sk); ?> <br>
                - <b>NO.</b> <?php echo e($d->no_sk); ?> <br>
                - <b>TGL.</b> <?php echo e(date("d/m/Y", strtotime($d->tgl_penetapan_sk))); ?> <br>
                - <b>TMT.</b> <?php echo e($d->tgl_mulai_tugas); ?>

            </td>
            <!-- <td><?php echo e(date("d/m/Y", strtotime($d->tgl_penetapan_sk))); ?></td>
            <td><?php echo e($d->no_sk); ?></td>
            <td><?php echo e(date("d/m/Y", strtotime($d->tgl_mulai_tugas))); ?></td> -->
            
            <td valign="top"><?php echo e($d->masa_kerja); ?></td>
            <td valign="top">Rp. <?php echo e(number_format($d->gaji_pokok,2,',','.')); ?></td>
            <td valign="top"><?php echo e($d->jabatan); ?></td>
            <td valign="top"><?php echo e($d->jenis_kelamin); ?></td>
            <td valign="top"><?php echo e($d->no_hp); ?></td>
            <td valign="top"><?php echo e($d->no_ktp); ?></td>
            <td valign="top"><?php echo e($d->email); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php break; ?>
    
    <?php case ('semua-pegawai'): ?>
    <table class="my-table" cellpadding="5" border="1">
        <tr class="bg-orange">
            <th style="width: 150px;">Nama</th>
            <th>NIP/NIK</th>
            <th>Jabatan</th>
            <th>Status Pegawai</th>
            <th>Bidang</th>
            <th>Jenis Kelamin</th>
            <th>No. HP</th>
            <th>No. KTP</th>
            <th>Email</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td valign="top"><?php echo e($d->nama); ?></td>
            <td valign="top">(<?php echo e($d->nip ? $d->nip : $d->nik); ?>)</td>
            <td valign="top"><?php echo e($d->jabatan); ?></td>
            <td align="center"><?php echo e($d->status_pegawai); ?></td>
            <td valign="top"><?php echo e($d->bidang); ?></td>
            <td valign="top"><?php echo e($d->jenis_kelamin); ?></td>
            <td valign="top"><?php echo e($d->no_hp); ?></td>
            <td valign="top"><?php echo e($d->no_ktp); ?></td>
            <td valign="top"><?php echo e($d->email); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php break; ?>

    <?php default: ?>

    <?php endswitch; ?>

    <!-- End of Content -->

    <?php echo $__env->make('templates.ttd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\Projek\e-pekerja-api\resources\views/printPegawai/rekap_pegawai.blade.php ENDPATH**/ ?>