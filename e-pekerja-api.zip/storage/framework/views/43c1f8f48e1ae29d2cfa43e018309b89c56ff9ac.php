<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">

<img src="https://upload.wikimedia.org/wikipedia/commons/3/38/Logo_Kota_Samarinda.png" class="logo" alt="Laravel Logo">

<h1 style="margin-top: 20px; font-size: 1.2em; text-align: center">Dinas Perumahan dan Permukiman Samarinda</h1>

</a>
</td>
</tr>
<?php /**PATH C:\Projek\e-pekerja-api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>