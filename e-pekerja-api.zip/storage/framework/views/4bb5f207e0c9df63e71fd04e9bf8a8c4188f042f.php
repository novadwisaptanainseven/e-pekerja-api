<div class="ttd-container" style="text-align: center; width: 300px; margin-left: auto; font-family: arial">
        <p style="margin-bottom: 50px;">Kepala Dinas</p>

        <p style="text-align: center">
            <span style="text-decoration: underline"><?php echo e($ttd->nama); ?></span> <br>
            <?php echo e($ttd->ket_golongan); ?> (<?php echo e($ttd->golongan); ?>) <br>
            NIP. <?php echo e($ttd->nip); ?>

        </p>
    </div><?php /**PATH C:\Projek\e-pekerja-api\resources\views/templates/ttd.blade.php ENDPATH**/ ?>