<table>
  <tr>
    <td></td>
  </tr>
  <tr>
      <td></td>
  </tr>
  <tr>
      <td></td>
  </tr>
  <tr>
      <td></td>
  </tr>
  <tr>
      <td></td>
  </tr>
  <tr>
      <th>No</th>
      <th>NIP/NIK</th>
      <th>Nama</th>
      <th>Status Pegawai</th>
      <th>Tgl. Berhenti</th>
      <th>Status</th>
      <th>Keterangan</th>
  </tr>
 
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
      <td><?php echo e($i + 1); ?></td>
      <td>(<?php echo e($item->nip); ?>)</td>
      <td><?php echo e($item->nama); ?></td>
      <td><?php echo e($item->status_pegawai); ?></td>
      <td><?php echo e(date('d/m/Y', strtotime($item->tgl_berhenti))); ?></td>
      <td><?php echo e($item->status_berhenti == "akan-berhenti" ? "Akan Berhenti" : "Berhenti"); ?></td>
      <td><?php echo e($item->keterangan); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table><?php /**PATH C:\Projek\e-pekerja-api\resources\views/exports/pegawai_berhenti.blade.php ENDPATH**/ ?>