<?php $__env->startComponent('mail::message'); ?>
# Halo Pegawai

<?php $__env->startComponent('mail::panel', ['url' => '']); ?>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugiat repellendus sequi amet dolorum delectus architecto sunt sed id. Dolore, velit! Corporis unde eligendi ipsam maiores dignissimos, suscipit magni nesciunt omnis.
<?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Terima Kasih,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Projek\e-pekerja-api\resources\views/emails/email-design.blade.php ENDPATH**/ ?>