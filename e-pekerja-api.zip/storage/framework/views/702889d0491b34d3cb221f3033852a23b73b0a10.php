[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Projek\e-pekerja-api\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>